# Boutique gratuite — première version

1. Ouvre `index.html` pour tester la boutique.
2. Dans le code, modifie la liste `products` pour ajouter/supprimer des articles et changer les prix.
3. Remplace `NOVA SHOP` par le nom de ta boutique.
4. Remplace le numéro `262000000000` par ton numéro WhatsApp.
5. Remplace les blocs `PHOTO PRODUIT` par tes vraies photos.
6. Pour la mise en ligne gratuite, tu peux utiliser GitHub Pages ou Cloudflare Pages.

Cette version comprend : accueil, catégories, produits, panier, total, formulaire de commande et envoi de commande via WhatsApp.
